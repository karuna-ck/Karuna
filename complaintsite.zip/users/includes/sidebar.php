<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="profile.html"><img src="https://images.unsplash.com/photo-1514285490982-4130e9aefedb?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80" class="img-circle" width="60"></a></p>
                   <?php $query=mysql_query("select fullName from users where userEmail='".$_SESSION['login']."'");
 while($row=mysql_fetch_array($query)) 
 {
 ?> 
              	  <h5 class="centered"><?php echo htmlentities($row['fullName']);?></h5>
                  <?php } ?>
              	  	
                  <li class="mt">
                      <a href="dashboard.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>


                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-cogs"></i>
                          <span>Manage Accounts</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="profile.php">Profile</a></li>
                          <li><a  href="change-password.php">Change Password</a></li>
                        
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-book"></i>
                          <span>Manage Complaints</span>
                      </a>
                      <ul class="sub">
                       <li>
                         <a href="register-complaint.php" >
                          <i class="fa fa-book"></i>
                          <span>Create Complaint</span>
                          </a>
                       </li>
                       <li>
                         
                          <a href="complaint-history.php" >
                              <i class="fa fa-tasks"></i>
                              <span>Complaint History</span>
                          </a>
                       </li>
                        
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="logout.php" >
                          <i class="fa 
fa-sign-out"></i>
                          <span>Logout</span>
                      </a>
                    </li>
                  </li> 
                 
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>